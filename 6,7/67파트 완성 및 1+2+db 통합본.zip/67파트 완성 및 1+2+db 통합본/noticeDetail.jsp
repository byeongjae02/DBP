<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%>
<%
    int noticeId = Integer.parseInt(request.getParameter("id"));
    String sessionId = (String) session.getAttribute("sessionId");
    String sessionRole = (String) session.getAttribute("sessionRole");
    
    // 🔥 무적의 관리자 체크 (권한이 대소문자 상관없이 admin이거나, 아이디 자체가 admin일 때)
    boolean isAdmin = (sessionRole != null && sessionRole.equalsIgnoreCase("ADMIN")) || 
                      (sessionId != null && sessionId.equalsIgnoreCase("admin"));
%>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<title>공지사항 상세보기</title>
</head>
<body>

<jsp:include page="menu.jsp"/>

<div class="container mt-5">
    <%
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String url = "jdbc:h2:tcp://localhost/~/bookmarketdb";
        String user = "user1";
        String dbPassword = "1234";

        try {
            Class.forName("org.h2.Driver");
            conn = DriverManager.getConnection(url, user, dbPassword);
            String sql = "SELECT * FROM notices WHERE notice_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, noticeId);
            rs = pstmt.executeQuery();

            if(rs.next()) {
                String writer = rs.getString("writer");
    %>
                <div class="card shadow-sm">
                    <div class="card-header bg-dark text-white">
                        <h3><%=rs.getString("title")%></h3>
                        <div class="text-right">
                            <small>작성자: <%=writer%> | 작성일: <%=rs.getDate("created_at")%></small>
                        </div>
                    </div>
                    <div class="card-body" style="min-height: 250px; font-size: 1.1rem; white-space: pre-wrap;"><%=rs.getString("content")%></div>
                </div>
                
                <div class="text-center mt-4">
                    <% 
                        // 관리자(admin)이거나 내가 쓴 글이면 삭제 버튼 노출
                        boolean isWriter = (sessionId != null && sessionId.equals(writer));
                        if (isAdmin || isWriter) { 
                    %>
                        <a href="processDeleteNotice.jsp?id=<%=noticeId%>" class="btn btn-danger" onclick="return confirm('이 공지사항을 정말 삭제하시겠습니까?');">삭제하기</a>
                    <% 
                        } 
                    %>
                    <a href="noticeList.jsp" class="btn btn-secondary">목록으로</a>
                </div>
    <%
            }
        } catch(Exception e) {
            e.printStackTrace();
        } finally {
            if(rs != null) rs.close();
            if(pstmt != null) pstmt.close();
            if(conn != null) conn.close();
        }
    %>
</div>

<jsp:include page="footer.jsp"/>

</body>
</html>