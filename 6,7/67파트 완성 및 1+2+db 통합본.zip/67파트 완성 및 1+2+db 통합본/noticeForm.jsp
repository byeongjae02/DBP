<%@ page contentType="text/html; charset=utf-8"%>
<%
    String sessionRole = (String) session.getAttribute("sessionRole");
    if(sessionRole == null || !"ADMIN".equals(sessionRole)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<title>공지사항 작성</title>
</head>
<body>

<jsp:include page="menu.jsp"/>

<div class="jumbotron">
	<div class="container">
		<h1 class="display-4">공지사항 작성</h1>
		<p>연구실 공지사항을 등록합니다.</p>
	</div>
</div>

<div class="container">
	<div class="col-md-8 offset-md-2">
		<form action="processAddNotice.jsp" method="post">
			<div class="form-group">
				<label>제목</label>
				<input type="text" name="title" class="form-control" required>
			</div>
			<div class="form-group">
				<label>내용</label>
				<textarea name="content" rows="8" class="form-control" required></select></textarea>
			</div>
			<div class="text-center mt-4">
				<input type="submit" class="btn btn-primary px-5" value="게시하기">
				<a href="noticeList.jsp" class="btn btn-secondary">취소</a>
			</div>
		</form>
	</div>
</div>

<jsp:include page="footer.jsp"/>

</body>
</html>