<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%>
<%
    String sessionRole = (String) session.getAttribute("sessionRole");
%>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<title>공지사항</title>
</head>
<body>

<jsp:include page="menu.jsp"/>

<div class="jumbotron">
	<div class="container">
		<h1 class="display-4">공지사항</h1>
		<p>연구실의 주요 소식과 공지사항을 전달합니다.</p>
	</div>
</div>

<div class="container">
    <% if("ADMIN".equals(sessionRole)) { %>
        <div class="text-right mb-3">
            <a href="noticeForm.jsp" class="btn btn-primary">글쓰기</a>
        </div>
    <% } %>

    <div class="list-group">
    <%
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String url = "jdbc:h2:tcp://localhost/~/bookmarketdb";
        String user = "user1";
        String dbPassword = "1234";

        try {
            Class.forName("org.h2.Driver");
            conn = DriverManager.getConnection(url, user, dbPassword);
            String sql = "SELECT * FROM notices ORDER BY notice_id DESC";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            boolean hasNotices = false;
            while(rs.next()) {
                hasNotices = true;
    %>
                <a href="noticeDetail.jsp?id=<%=rs.getInt("notice_id")%>" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1 text-dark"><b><%=rs.getString("title")%></b></h5>
                        <small class="text-muted">작성일: <%=rs.getDate("created_at")%></small>
                    </div>
                    <small class="text-secondary">작성자: <%=rs.getString("writer")%></small>
                </a>
    <%
            }
            if(!hasNotices) {
    %>
                <div class="text-center py-5 text-muted">등록된 공지사항이 없습니다.</div>
    <%
            }
        } catch(Exception e) {
            e.printStackTrace();
        } finally {
            if(rs != null) rs.close();
            if(pstmt != null) pstmt.close();
            if(conn != null) conn.close();
        }
    %>
    </div>
</div>

<jsp:include page="footer.jsp"/>

</body>
</html>