<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%>
<%
    // 삭제할 공지사항 번호를 받아옵니다.
    String id = request.getParameter("id");

    Connection conn = null;
    PreparedStatement pstmt = null;

    String url = "jdbc:h2:tcp://localhost/~/bookmarketdb";
    String user = "user1";
    String dbPassword = "1234";

    try {
        Class.forName("org.h2.Driver");
        conn = DriverManager.getConnection(url, user, dbPassword);
        
        // 💡 딜리트(DELETE) 쿼리 발사!
        String sql = "DELETE FROM notices WHERE notice_id = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, Integer.parseInt(id));
        
        pstmt.executeUpdate();
        
        // 지우고 나서 다시 공지사항 목록으로 돌아감
        response.sendRedirect("noticeList.jsp");

    } catch(Exception e) {
        e.printStackTrace();
%>
        <script>
            alert("삭제 중 에러가 발생했습니다.");
            history.back();
        </script>
<%
    } finally {
        if(pstmt != null) pstmt.close();
        if(conn != null) conn.close();
    }
%>