<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%>
<%
    request.setCharacterEncoding("UTF-8");

    // 1. 프로젝트 기본 정보 가져오기
    String projectName = request.getParameter("projectName");
    String projectType = request.getParameter("projectType");
    String description = request.getParameter("description");
    String startDate = request.getParameter("startDate");
    String endDate = request.getParameter("endDate");
    String projectStatus = request.getParameter("projectStatus");
    
    // 🔥 2. 체크박스에서 선택된 랩원들의 ID 배열 가져오기
    String[] selectedMembers = request.getParameterValues("members");

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rsKeys = null;

    String url = "jdbc:h2:tcp://localhost/~/bookmarketdb";
    String user = "user1";
    String dbPassword = "1234";

    try {
        Class.forName("org.h2.Driver");
        conn = DriverManager.getConnection(url, user, dbPassword);
        
        // 💡 핵심 기술: 프로젝트를 등록하고, 방금 생성된 project_id를 알아내기 위한 세팅 (RETURN_GENERATED_KEYS)
        String sql = "INSERT INTO projects(project_name, project_type, description, start_date, end_date, project_status) VALUES(?, ?, ?, ?, ?, ?)";
        pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        pstmt.setString(1, projectName);
        pstmt.setString(2, projectType);
        pstmt.setString(3, description);
        pstmt.setDate(4, Date.valueOf(startDate));
        pstmt.setDate(5, Date.valueOf(endDate));
        pstmt.setString(6, projectStatus);

        // 프로젝트 DB에 삽입!
        pstmt.executeUpdate();
        
        // 방금 삽입된 프로젝트의 번호(ID) 알아내기
        rsKeys = pstmt.getGeneratedKeys();
        int newProjectId = -1;
        if(rsKeys.next()) {
            newProjectId = rsKeys.getInt(1);
        }
        
        // 🔥 체크된 참여 랩원이 있다면 project_members 테이블에 차례대로 밀어넣기
        if (newProjectId != -1 && selectedMembers != null) {
            String pmSql = "INSERT INTO project_members(project_id, member_id, project_role, joined_date) VALUES(?, ?, '참여연구원', CURRENT_DATE)";
            PreparedStatement pmStmt = conn.prepareStatement(pmSql);
            
            for(String memberId : selectedMembers) {
                pmStmt.setInt(1, newProjectId);                     // 방금 만든 프로젝트 번호
                pmStmt.setInt(2, Integer.parseInt(memberId));       // 체크된 랩원의 번호
                pmStmt.executeUpdate();                             // DB에 저장
            }
            if(pmStmt != null) pmStmt.close();
        }

        // 모든 저장이 끝나면 프로젝트 목록으로 이동
        response.sendRedirect("projectList.jsp");

    } catch(Exception e) {
        e.printStackTrace();
%>
        <script>
            alert("프로젝트 등록 중 에러가 발생했습니다.");
            history.back();
        </script>
<%
    } finally {
        if(rsKeys != null) rsKeys.close();
        if(pstmt != null) pstmt.close();
        if(conn != null) conn.close();
    }
%>