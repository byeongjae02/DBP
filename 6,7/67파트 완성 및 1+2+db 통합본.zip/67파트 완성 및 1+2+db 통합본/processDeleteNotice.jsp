<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%>
<%
    // 삭제할 공지사항 번호 가져오기
    String id = request.getParameter("id");

    Connection conn = null;
    PreparedStatement pstmt = null;

    String url = "jdbc:h2:tcp://localhost/~/bookmarketdb";
    String user = "user1";
    String dbPassword = "1234";

    try {
        // 혹시 번호가 안 넘어왔을 경우 튕겨내기
        if(id == null || id.trim().equals("")) {
            throw new Exception("삭제할 공지사항 번호(id)가 전달되지 않았습니다.");
        }

        Class.forName("org.h2.Driver");
        conn = DriverManager.getConnection(url, user, dbPassword);
        
        // 💡 공지사항 삭제 쿼리 실행
        String sql = "DELETE FROM notices WHERE notice_id = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, Integer.parseInt(id));
        
        int result = pstmt.executeUpdate();
        
        // 정상 삭제되었다면 목록으로 이동
        if(result > 0) {
            response.sendRedirect("noticeList.jsp");
        } else {
            throw new Exception("해당 공지사항이 이미 삭제되었거나 DB에 존재하지 않습니다.");
        }

    } catch(Exception e) {
        // 🔥 에러의 진짜 원인을 파악하기 위해 메시지를 정리해서 팝업으로 띄웁니다!
        String errorMsg = e.getMessage();
        if(errorMsg != null) {
            errorMsg = errorMsg.replace("\"", "'").replace("\n", " ");
        }
%>
        <script>
            alert("공지사항 삭제 실패! 원인: <%=errorMsg%>");
            history.back();
        </script>
<%
    } finally {
        if(pstmt != null) pstmt.close();
        if(conn != null) conn.close();
    }
%>