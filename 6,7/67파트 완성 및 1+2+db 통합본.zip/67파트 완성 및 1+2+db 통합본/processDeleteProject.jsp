<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%>
<%
    String id = request.getParameter("id");

    Connection conn = null;
    PreparedStatement pstmt1 = null;
    PreparedStatement pstmt2 = null;

    String url = "jdbc:h2:tcp://localhost/~/bookmarketdb";
    String user = "user1";
    String dbPassword = "1234";

    try {
        Class.forName("org.h2.Driver");
        conn = DriverManager.getConnection(url, user, dbPassword);
        
        // 1. 자식 테이블(참여자 목록) 먼저 삭제 (외래키 충돌 방지)
        String sql1 = "DELETE FROM project_members WHERE project_id = ?";
        pstmt1 = conn.prepareStatement(sql1);
        pstmt1.setInt(1, Integer.parseInt(id));
        pstmt1.executeUpdate();
        
        // 2. 부모 테이블(프로젝트) 최종 삭제
        String sql2 = "DELETE FROM projects WHERE project_id = ?";
        pstmt2 = conn.prepareStatement(sql2);
        pstmt2.setInt(1, Integer.parseInt(id));
        pstmt2.executeUpdate();
        
        // 삭제 성공 시 프로젝트 목록으로 이동
        response.sendRedirect("projectList.jsp");

    } catch(Exception e) {
        e.printStackTrace();
%>
        <script>
            alert("프로젝트 삭제 중 에러가 발생했습니다.");
            history.back();
        </script>
<%
    } finally {
        if(pstmt1 != null) pstmt1.close();
        if(pstmt2 != null) pstmt2.close();
        if(conn != null) conn.close();
    }
%>