<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%>
<%
    int projectId = Integer.parseInt(request.getParameter("id"));
    String sessionId = (String) session.getAttribute("sessionId");
    String sessionRole = (String) session.getAttribute("sessionRole");
    
    // 🔥 무적의 관리자 체크
    boolean isAdmin = (sessionRole != null && sessionRole.equalsIgnoreCase("ADMIN")) || 
                      (sessionId != null && sessionId.equalsIgnoreCase("admin"));
%>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<title>프로젝트 상세 정보</title>
</head>
<body>

<jsp:include page="menu.jsp"/>

<div class="container mt-5">
    <%
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String url = "jdbc:h2:tcp://localhost/~/bookmarketdb";
        String user = "user1";
        String dbPassword = "1234";

        try {
            Class.forName("org.h2.Driver");
            conn = DriverManager.getConnection(url, user, dbPassword);
            
            // 프로젝트 기본 정보 조회
            String sql = "SELECT * FROM projects WHERE project_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, projectId);
            rs = pstmt.executeQuery();

            if(rs.next()) {
    %>
                <div class="card bg-light mb-4">
                    <div class="card-body">
                        <h2 class="card-title text-primary"><%=rs.getString("project_name")%></h2>
                        <h6 class="card-subtitle mb-2 text-muted">구분: <%=rs.getString("project_type")%> | 상태: <%=rs.getString("project_status")%></h6>
                        <hr>
                        <p class="card-text" style="font-size: 1.2rem;"><%=rs.getString("description")%></p>
                        <p class="text-secondary">기간: <%=rs.getDate("start_date")%> ~ <%=rs.getDate("end_date")%></p>
                    </div>
                </div>
    <%
            }
            if(rs != null) rs.close();
            if(pstmt != null) pstmt.close();

            // 참여 랩원 조회
            String joinSql = "SELECT m.name, m.department, pm.project_role, pm.joined_date " +
                             "FROM project_members pm " +
                             "JOIN members m ON pm.member_id = m.member_id " +
                             "WHERE pm.project_id = ?";
            pstmt = conn.prepareStatement(joinSql);
            pstmt.setInt(1, projectId);
            rs = pstmt.executeQuery();
    %>
            <h4 class="mt-5 mb-3">👨‍💻 참여 연구원 목록</h4>
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>이름</th>
                        <th>소속 학과</th>
                        <th>프로젝트 내 역할</th>
                        <th>참여일</th>
                    </tr>
                </thead>
                <tbody>
                <%
                    boolean hasMembers = false;
                    while(rs.next()) {
                        hasMembers = true;
                %>
                    <tr>
                        <td><b><%=rs.getString("name")%></b></td>
                        <td><%=rs.getString("department")%></td>
                        <td><span class="badge badge-warning"><%=rs.getString("project_role")%></span></td>
                        <td><%=rs.getDate("joined_date")%></td>
                    </tr>
                <%
                    }
                    if(!hasMembers) {
                %>
                    <tr>
                        <td colspan="4" class="text-center text-muted">현재 이 프로젝트에 배정된 랩원이 없습니다.</td>
                    </tr>
                <%
                    }
                %>
                </tbody>
            </table>
    <%
        } catch(Exception e) {
            e.printStackTrace();
        } finally {
            if(rs != null) rs.close();
            if(pstmt != null) pstmt.close();
            if(conn != null) conn.close();
        }
    %>
    
    <div class="text-center mt-4 mb-5">
        <% if(isAdmin) { %>
            <a href="processDeleteProject.jsp?id=<%=projectId%>" class="btn btn-danger mr-2" onclick="return confirm('정말 삭제하시겠습니까? 참여 중인 랩원들의 정보도 프로젝트에서 제외됩니다.');">프로젝트 삭제</a>
        <% } %>
        <a href="projectList.jsp" class="btn btn-secondary">목록으로 돌아가기</a>
    </div>
</div>

<jsp:include page="footer.jsp"/>

</body>
</html>