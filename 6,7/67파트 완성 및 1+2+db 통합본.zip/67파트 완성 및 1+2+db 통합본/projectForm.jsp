<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%>
<%
    String sessionRole = (String) session.getAttribute("sessionRole");
    if(sessionRole == null || !"ADMIN".equals(sessionRole)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<title>새 프로젝트 등록</title>
</head>
<body>

<jsp:include page="menu.jsp"/>

<div class="jumbotron">
	<div class="container">
		<h1 class="display-4">프로젝트 등록</h1>
		<p>새로운 연구실 과제 및 프로젝트를 추가합니다.</p>
	</div>
</div>

<div class="container">
	<div class="col-md-8 offset-md-2">
		<form action="processAddProject.jsp" method="post">
			<div class="form-group">
				<label>프로젝트명</label>
				<input type="text" name="projectName" class="form-control" required>
			</div>
			<div class="form-group">
				<label>프로젝트 구분</label>
				<select name="projectType" class="form-control">
					<option value="토이프로젝트">토이프로젝트</option>
					<option value="소학회">소학회</option>
					<option value="튜터링">튜터링</option>
					<option value="국책과제">국책과제</option>
				</select>
			</div>
			<div class="form-group">
				<label>상세 설명</label>
				<textarea name="description" rows="4" class="form-control" required></textarea>
			</div>
			
			<div class="form-group">
				<label class="font-weight-bold text-primary">👨‍💻 참여 연구원 선택 (다중 선택 가능)</label>
				<div class="border p-3 rounded bg-light" style="max-height: 150px; overflow-y: auto;">
				<%
					Connection conn = null;
					PreparedStatement pstmt = null;
					ResultSet rs = null;
					
					String url = "jdbc:h2:tcp://localhost/~/bookmarketdb";
					String user = "user1";
					String dbPassword = "1234";
					
					try {
						Class.forName("org.h2.Driver");
						conn = DriverManager.getConnection(url, user, dbPassword);
						// members 테이블에서 랩원 목록을 가져옴
						String sql = "SELECT member_id, name, lab_role FROM members ORDER BY name";
						pstmt = conn.prepareStatement(sql);
						rs = pstmt.executeQuery();
						
						boolean hasMembers = false;
						while(rs.next()) {
							hasMembers = true;
				%>
							<div class="form-check mb-1">
								<input class="form-check-input" type="checkbox" name="members" value="<%=rs.getInt("member_id")%>" id="member_<%=rs.getInt("member_id")%>">
								<label class="form-check-label" for="member_<%=rs.getInt("member_id")%>">
									<%=rs.getString("name")%> <span class="text-secondary" style="font-size: 0.9em;">(<%=rs.getString("lab_role") != null ? rs.getString("lab_role") : "역할미정"%>)</span>
								</label>
							</div>
				<%
						}
						if(!hasMembers) {
							out.print("<span class='text-danger'>현재 DB에 등록된 랩원이 없습니다. [랩원목록] 메뉴에서 먼저 랩원을 등록해주세요!</span>");
						}
					} catch(Exception e) {
						out.print("랩원 목록을 불러오는 중 오류가 발생했습니다.");
					} finally {
						if(rs != null) rs.close();
						if(pstmt != null) pstmt.close();
						if(conn != null) conn.close();
					}
				%>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6 form-group">
					<label>시작일</label>
					<input type="date" name="startDate" class="form-control" required>
				</div>
				<div class="col-md-6 form-group">
					<label>종료일</label>
					<input type="date" name="endDate" class="form-control" required>
				</div>
			</div>
			<div class="form-group">
				<label>진행 상태</label>
				<select name="projectStatus" class="form-control">
					<option value="계획중">계획중</option>
					<option value="진행중" selected>진행중</option>
					<option value="완료">완료</option>
				</select>
			</div>
			<div class="text-center mt-5 mb-5">
				<input type="submit" class="btn btn-primary px-5" value="프로젝트 등록하기">
				<a href="projectList.jsp" class="btn btn-secondary">취소</a>
			</div>
		</form>
	</div>
</div>

<jsp:include page="footer.jsp"/>

</body>
</html>