<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%>
<%
    String sessionId = (String) session.getAttribute("sessionId");
    String sessionRole = (String) session.getAttribute("sessionRole");
%>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<title>프로젝트 관리</title>
</head>
<body>

<jsp:include page="menu.jsp"/>

<div class="jumbotron">
	<div class="container">
		<h1 class="display-4">프로젝트 관리</h1>
		<p>연구실에서 진행 중인 프로젝트 목록입니다.</p>
	</div>
</div>

<div class="container">
    <% if("ADMIN".equals(sessionRole)) { %>
        <div class="text-right mb-3">
            <a href="projectForm.jsp" class="btn btn-success">+ 새 프로젝트 등록</a>
        </div>
    <% } %>

    <table class="table table-hover">
        <thead class="thead-dark">
            <tr>
                <th>번호</th>
                <th>프로젝트명</th>
                <th>구분</th>
                <th>시작일</th>
                <th>종료일</th>
                <th>상태</th>
            </tr>
        </thead>
        <tbody>
        <%
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;

            String url = "jdbc:h2:tcp://localhost/~/bookmarketdb";
            String user = "user1";
            String dbPassword = "1234";

            try {
                Class.forName("org.h2.Driver");
                conn = DriverManager.getConnection(url, user, dbPassword);
                String sql = "SELECT * FROM projects ORDER BY project_id";
                pstmt = conn.prepareStatement(sql);
                rs = pstmt.executeQuery();

                while(rs.next()) {
        %>
                <tr>
                    <td><%=rs.getInt("project_id")%></td>
                    <td>
                        <a href="projectDetail.jsp?id=<%=rs.getInt("project_id")%>">
                            <b><%=rs.getString("project_name")%></b>
                        </a>
                    </td>
                    <td><span class="badge badge-info"><%=rs.getString("project_type")%></span></td>
                    <td><%=rs.getDate("start_date")%></td>
                    <td><%=rs.getDate("end_date")%></td>
                    <td>
                        <% if("진행중".equals(rs.getString("project_status"))) { %>
                            <span class="badge badge-success">진행중</span>
                        <% } else { %>
                            <span class="badge badge-secondary"><%=rs.getString("project_status")%></span>
                        <% } %>
                    </td>
                </tr>
        <%
                }
            } catch(Exception e) {
                e.printStackTrace();
            } finally {
                if(rs != null) rs.close();
                if(pstmt != null) pstmt.close();
                if(conn != null) conn.close();
            }
        %>
        </tbody>
    </table>
</div>

<jsp:include page="footer.jsp"/>

</body>
</html>